/** Pakiet przechowujący testy klas serwera pochodzące z pakietu pl.app.server */
package pl.app.tests;