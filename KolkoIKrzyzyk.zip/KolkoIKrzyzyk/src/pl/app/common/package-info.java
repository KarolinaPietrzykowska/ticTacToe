/** Pakiet przechowujący klasy do obsługi klienta i serwera */
package pl.app.common;