/** Pakiet przechowujący klasy do obsługi klienta */
package pl.app.client;